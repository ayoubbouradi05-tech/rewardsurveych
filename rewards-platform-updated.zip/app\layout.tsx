import type { Metadata } from 'next'
import './globals.css'

export const metadata: Metadata = {
  title: 'RewardHub — Earn Real Money Completing Offers',
  description: 'Complete surveys, offers and tasks to earn USDT. Join thousands of members earning real cryptocurrency rewards.',
  keywords: 'earn money online, rewards, offers, surveys, USDT, cryptocurrency rewards',
  openGraph: {
    title: 'RewardHub — Earn Real Money Completing Offers',
    description: 'Complete surveys, offers and tasks to earn USDT.',
    type: 'website',
  },
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap"
          rel="stylesheet"
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
