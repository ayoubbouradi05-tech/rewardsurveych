import React, { useState, useEffect, useCallback } from 'react';
import { 
  Coins, 
  DollarSign, 
  TrendingUp, 
  CheckCircle, 
  Clock, 
  ArrowLeftRight, 
  Wallet, 
  LogOut, 
  Grid, 
  Layers, 
  ShieldCheck, 
  User, 
  AlertCircle, 
  Check, 
  X, 
  ExternalLink, 
  RefreshCw, 
  Sliders, 
  Database,
  Users,
  Activity,
  Award,
  ArrowRight,
  Sparkles,
  Info
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { User as UserType, Offer, Conversion, Withdrawal, Transaction, DashboardStats, AdminStats } from './types';

// Storage item keys
const AUTH_TOKEN_KEY = 'rewardtask_token';

export default function App() {
  // Session states
  const [token, setToken] = useState<string | null>(localStorage.getItem(AUTH_TOKEN_KEY));
  const [currentUser, setCurrentUser] = useState<UserType | null>(null);
  const [userStats, setUserStats] = useState<DashboardStats | null>(null);
  const [offers, setOffers] = useState<Offer[]>([]);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'offers' | 'withdraw' | 'history' | 'admin'>('dashboard');
  
  // Auth Form states
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [authSuccess, setAuthSuccess] = useState('');
  
  // Withdraw Form states
  const [usdtAddress, setUsdtAddress] = useState('');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawError, setWithdrawError] = useState('');
  const [withdrawSuccess, setWithdrawSuccess] = useState('');
  
  // Admin Data states
  const [adminStats, setAdminStats] = useState<AdminStats | null>(null);
  const [adminUsers, setAdminUsers] = useState<UserType[]>([]);
  const [adminConversions, setAdminConversions] = useState<Conversion[]>([]);
  const [adminWithdrawals, setAdminWithdrawals] = useState<Withdrawal[]>([]);
  
  // Feed & view filter states
  const [offersFilter, setOffersFilter] = useState<string>('All');
  const [isLoading, setIsLoading] = useState(false);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Postback Sandbox States
  const [simulatedPayout, setSimulatedPayout] = useState('1.50');
  const [selectedOfferForSimulation, setSelectedOfferForSimulation] = useState<Offer | null>(null);
  const [simulatingLog, setSimulatingLog] = useState<{ url: string; response: any; status: 'idle' | 'loading' | 'success' | 'error' }>({
    url: '',
    response: null,
    status: 'idle'
  });

  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' | 'info' } | null>(null);

  // Auto-clear toast helper
  const showToast = useCallback((message: string, type: 'success' | 'error' | 'info' = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 4000);
  }, []);

  // API Call helper
  const apiRequest = useCallback(async (path: string, options: RequestInit = {}) => {
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers
    };
    const res = await fetch(path, { ...options, headers });
    const json = await res.json();
    if (!res.ok) {
      throw new Error(json.error || 'Something went wrong');
    }
    return json;
  }, [token]);

  // Listen for Google login message from popup
  useEffect(() => {
    const handleGoogleMessage = (event: MessageEvent) => {
      // Security check: Validate origin
      const origin = event.origin;
      if (!origin.endsWith('.run.app') && !origin.includes('localhost') && !origin.includes('127.0.0.1')) {
        return;
      }
      
      if (event.data?.type === 'OAUTH_AUTH_SUCCESS') {
        const { token: gToken, user: gUser } = event.data;
        if (gToken && gUser) {
          localStorage.setItem(AUTH_TOKEN_KEY, gToken);
          setToken(gToken);
          setCurrentUser(gUser);
          showToast("Authenticated with Google account successfully!", "success");
        }
      }
    };
    
    window.addEventListener('message', handleGoogleMessage);
    return () => window.removeEventListener('message', handleGoogleMessage);
  }, []);

  // Fetch Current User
  useEffect(() => {
    if (!token) {
      setCurrentUser(null);
      setUserStats(null);
      return;
    }

    setIsLoading(true);
    apiRequest('/api/auth/me')
      .then(data => {
        setCurrentUser(data.user);
      })
      .catch(err => {
        console.error(err);
        logout();
      })
      .finally(() => setIsLoading(false));
  }, [token, refreshTrigger]);

  // Fetch User Stats, Transactions, Withdrawals, Conversions
  useEffect(() => {
    if (!currentUser) return;

    apiRequest('/api/dashboard/stats')
      .then(data => {
        setUserStats(data);
      })
      .catch(err => console.error("Error loading stats:", err));
  }, [currentUser, refreshTrigger]);

  // Fetch Offers
  useEffect(() => {
    setIsLoading(true);
    apiRequest('/api/offers')
      .then(data => {
        setOffers(data);
        if (data.length > 0 && !selectedOfferForSimulation) {
          setSelectedOfferForSimulation(data[0]);
        }
      })
      .catch(err => {
        console.error("Error loading offers:", err);
        showToast("Dynamic Offers API offline, loaded Fallback Offers.", "info");
      })
      .finally(() => setIsLoading(false));
  }, [currentUser, refreshTrigger]);

  // Fetch Admin Panels
  useEffect(() => {
    if (!currentUser || currentUser.role !== 'admin' || activeTab !== 'admin') return;

    // Load admin panel collections
    const fetchAdminData = async () => {
      try {
        const [statsData, usersList, conversionsList, withdrawalsList] = await Promise.all([
          apiRequest('/api/admin/stats'),
          apiRequest('/api/admin/users'),
          apiRequest('/api/admin/conversions'),
          apiRequest('/api/admin/withdrawals')
        ]);
        setAdminStats(statsData);
        setAdminUsers(usersList);
        setAdminConversions(conversionsList);
        setAdminWithdrawals(withdrawalsList);
      } catch (err: any) {
        showToast(err.message, "error");
      }
    };

    fetchAdminData();
  }, [currentUser, activeTab, refreshTrigger]);

  // Login handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setIsLoading(true);

    try {
      const data = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      localStorage.setItem(AUTH_TOKEN_KEY, data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      showToast("Access Granted and Logged In!", "success");
      // reset forms
      setEmail('');
      setPassword('');
    } catch (err: any) {
      setAuthError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Signup handler
  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthSuccess('');
    setIsLoading(true);

    try {
      const data = await apiRequest('/api/auth/signup', {
        method: 'POST',
        body: JSON.stringify({ email, password })
      });
      localStorage.setItem(AUTH_TOKEN_KEY, data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      showToast("Profile Created! Enjoy $5.00 Sign up Rewards!", "success");
      // reset forms
      setEmail('');
      setPassword('');
    } catch (err: any) {
      setAuthError(err.message);
    } finally {
      setIsLoading(false);
    }
  };

  // Demo account quick start keys
  const triggerQuickLogin = async (role: 'user' | 'admin') => {
    const demoEmail = role === 'admin' ? 'admin@rewardtask.com' : 'user@rewardtask.com';
    const demoPassword = role === 'admin' ? 'admin123' : 'user123';
    setIsLoading(true);
    setAuthError('');

    try {
      const data = await apiRequest('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify({ email: demoEmail, password: demoPassword })
      });
      localStorage.setItem(AUTH_TOKEN_KEY, data.token);
      setToken(data.token);
      setCurrentUser(data.user);
      showToast(`Quick Access: Synced as ${role === 'admin' ? 'Administrator' : 'Standard User'}`, "success");
    } catch (err: any) {
      setAuthError("Seed users initialization missed. Please complete manually.");
    } finally {
      setIsLoading(false);
    }
  };

  // Trigger popup Google Authorization
  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setAuthError('');
    try {
      const targetOrigin = window.location.origin;
      const res = await fetch(`/api/auth/google/url?origin=${encodeURIComponent(targetOrigin)}`);
      if (!res.ok) {
        throw new Error("Could not retrieve Google sign-in configuration.");
      }
      const data = await res.json();
      
      const width = 500;
      const height = 610;
      const left = window.screen.width / 2 - width / 2;
      const top = window.screen.height / 2 - height / 2;
      
      const googleWindow = window.open(
        data.url,
        "Google Sign-In",
        `width=${width},height=${height},top=${top},left=${left},scrollbars=yes,status=yes`
      );
      
      if (!googleWindow) {
        setAuthError("Popup blocked! Google authorization failed. Please allow popups for this site to sign in with Google.");
        showToast("Access blocked by browser popup settings", "error");
      }
    } catch (err: any) {
      setAuthError(err.message);
      showToast(err.message, "error");
    } finally {
      setIsLoading(false);
    }
  };

  // Logout handler
  const logout = () => {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    setToken(null);
    setCurrentUser(null);
    setUserStats(null);
    setActiveTab('dashboard');
    showToast("Logged out successfully. See you soon!", "info");
  };

  // Submit withdrawal request
  const handleWithdrawalRequest = async (e: React.FormEvent) => {
    e.preventDefault();
    setWithdrawError('');
    setWithdrawSuccess('');

    if (!usdtAddress.startsWith('T') || usdtAddress.length < 24) {
      setWithdrawError('Error: Invalid TRC-20 wallet format. USDT TRC20 addresses begin with letters T and have 34 character lengths.');
      return;
    }

    try {
      const data = await apiRequest('/api/withdrawals', {
        method: 'POST',
        body: JSON.stringify({
          usdtAddress,
          amount: parseFloat(withdrawAmount)
        })
      });
      
      setWithdrawSuccess(data.message);
      setWithdrawAmount('');
      setUsdtAddress('');
      setRefreshTrigger(prev => prev + 1);
      showToast("Order submitted!", "success");
    } catch (err: any) {
      setWithdrawError(err.message);
    }
  };

  // Simulate Postback Call
  const handleSimulatedPostback = async () => {
    if (!currentUser) {
      showToast("Please log in first to track conversions to a user ID.", "error");
      return;
    }

    const oId = selectedOfferForSimulation?.id || "fall_test";
    const oName = selectedOfferForSimulation?.title || "Premium Partner Survey";
    const payoutRaw = parseFloat(simulatedPayout) || 1.50;

    // Build the postback url simulating direct CPA postback firing
    const transactionId = `sim_${Math.random().toString(36).substr(2, 9)}`;
    const postbackUrl = `/api/postback?subid=${currentUser.id}&payout=${payoutRaw}&offer_id=${oId}&offer_name=${encodeURIComponent(oName)}&txn_id=${transactionId}`;

    setSimulatingLog({
      url: postbackUrl,
      response: null,
      status: 'loading'
    });

    try {
      const res = await fetch(postbackUrl);
      const data = await res.json();
      
      if (res.ok && data.success) {
        setSimulatingLog(prev => ({
          ...prev,
          response: data,
          status: 'success'
        }));
        setRefreshTrigger(prev => prev + 1);
        showToast(`Success! Postback Credited +$${payoutRaw.toFixed(2)} USDT!`, "success");
      } else {
        throw new Error(data.error || "Postback handoff failed");
      }
    } catch (err: any) {
      setSimulatingLog(prev => ({
        ...prev,
        response: err.message,
        status: 'error'
      }));
      showToast(err.message, "error");
    }
  };

  // Admin Approve Withdrawal
  const handleApproveWithdrawal = async (id: string) => {
    try {
      const res = await apiRequest(`/api/admin/withdrawals/${id}/approve`, { method: 'POST' });
      showToast(res.message, "success");
      setRefreshTrigger(prev => prev + 1);
    } catch (err: any) {
      showToast(err.message, "error");
    }
  };

  // Admin Reject Withdrawal
  const handleRejectWithdrawal = async (id: string) => {
    try {
      const res = await apiRequest(`/api/admin/withdrawals/${id}/reject`, { method: 'POST' });
      showToast(res.message, "info");
      setRefreshTrigger(prev => prev + 1);
    } catch (err: any) {
      showToast(err.message, "error");
    }
  };

  // Calculate stats summary helper
  const totalReceivedUserVolume = userStats?.recentWithdrawals
    .filter(w => w.status === 'approved')
    .reduce((sum, w) => sum + w.amount, 0) || 0;

  // Filter dynamic offers
  const filteredOffers = offers.filter(off => {
    if (offersFilter === 'All') return true;
    return off.category.toLowerCase() === offersFilter.toLowerCase();
  });

  return (
    <div className="min-h-screen bg-[#07090e] text-[#cbd5e1] font-sans flex flex-col antialiased text-[11px] selection:bg-emerald-500/20 selection:text-emerald-300">
      
      {/* Toast Notification */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className={`fixed top-3 right-3 z-50 flex items-center gap-2.5 px-3.5 py-2.5 rounded border text-[11px] max-w-sm shadow-2xl backdrop-blur-md ${
              toast.type === 'success' ? 'bg-[#0a1813]/95 border-emerald-500/40 text-emerald-200' :
              toast.type === 'error' ? 'bg-[#180a0a]/95 border-rose-500/40 text-rose-200' :
              'bg-[#0d121f]/95 border-blue-500/40 text-blue-200'
            }`}
          >
            {toast.type === 'success' && <Check className="h-4 w-4 text-emerald-400 shrink-0" />}
            {toast.type === 'error' && <AlertCircle className="h-4 w-4 text-rose-400 shrink-0" />}
            {toast.type === 'info' && <Info className="h-4 w-4 text-blue-400 shrink-0" />}
            <span className="font-semibold">{toast.message}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Nav Header */}
      <header className="border-b border-slate-900 bg-[#0a0d15] sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 h-12 flex items-center justify-between">
          
          <div className="flex items-center gap-2">
            <div className="h-7 w-7 rounded bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow-md">
              <Coins className="h-4 w-4 text-[#07090e] stroke-[2.5]" />
            </div>
            <div>
              <span className="text-sm font-bold tracking-tight font-display text-white">Reward<span className="text-emerald-400">Task</span></span>
              <span className="hidden sm:inline-block px-1.5 py-0.2 ml-1.5 text-[8px] uppercase font-bold tracking-wider rounded border border-emerald-500/20 bg-emerald-950/20 text-emerald-400 font-mono">CPA Premium</span>
            </div>
          </div>

          {currentUser ? (
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-1.5 px-2 py-1 rounded bg-slate-950 border border-slate-900">
                <Coins className="h-3.5 w-3.5 text-emerald-400" />
                <span className="text-xs font-bold text-emerald-400 font-mono">${currentUser.balance.toFixed(2)}</span>
                <span className="text-[9px] text-slate-500 font-mono">USDT</span>
              </div>
              
              <div className="hidden md:flex items-center gap-1.5 text-[10px] text-slate-400">
                <User className="h-3.5 w-3.5 text-slate-500" />
                <span className="truncate max-w-[120px] font-mono">{currentUser.email}</span>
              </div>

              <button 
                onClick={logout} 
                title="Log Out Session"
                className="h-7 w-7 rounded bg-slate-900 border border-slate-800 flex items-center justify-center hover:bg-rose-950/30 hover:border-rose-900/30 text-slate-400 hover:text-rose-450 transition"
              >
                <LogOut className="h-3.5 w-3.5" />
              </button>
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <span className="text-[9px] bg-slate-955 text-slate-400 px-2 py-1 rounded border border-slate-850 font-mono">Sandbox Mode</span>
            </div>
          )}
        </div>
      </header>

      {currentUser ? (
        <div className="flex-1 max-w-7xl w-full mx-auto px-4 py-4 flex flex-col md:flex-row gap-4">
          
          {/* Main Dashboard Sidebar Links */}
          <aside className="md:w-56 shrink-0 flex flex-row md:flex-col gap-1 p-0.5 overflow-x-auto md:overflow-y-auto bg-slate-950/20 rounded-md border border-slate-900 md:border-0 md:bg-transparent">
            <button 
              onClick={() => setActiveTab('dashboard')}
              aria-label="Overview Dashboard"
              className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-bold transition whitespace-nowrap md:w-full border ${
                activeTab === 'dashboard' 
                  ? 'bg-emerald-950/20 text-emerald-400 border-emerald-800/20 shadow-sm' 
                  : 'text-slate-400 border-transparent hover:bg-slate-900/40 hover:text-white'
              }`}
            >
              <Grid className="h-3.5 w-3.5" />
              User Dashboard
            </button>

            <button 
              onClick={() => setActiveTab('offers')}
              aria-label="CPA Offerwall"
              className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-bold transition whitespace-nowrap md:w-full border ${
                activeTab === 'offers' 
                  ? 'bg-emerald-950/20 text-emerald-400 border-emerald-800/20 shadow-sm' 
                  : 'text-slate-400 border-transparent hover:bg-slate-900/40 hover:text-white'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              Offers Offerwall
            </button>

            <button 
              onClick={() => setActiveTab('withdraw')}
              aria-label="Payouts Portal"
              className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-bold transition whitespace-nowrap md:w-full border ${
                activeTab === 'withdraw' 
                  ? 'bg-emerald-950/20 text-emerald-400 border-emerald-800/20 shadow-sm' 
                  : 'text-slate-400 border-transparent hover:bg-slate-900/40 hover:text-white'
              }`}
            >
              <Wallet className="h-3.5 w-3.5" />
              Withdraw USDT
            </button>

            <button 
              onClick={() => setActiveTab('history')}
              aria-label="Ledger Logs"
              className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-bold transition whitespace-nowrap md:w-full border ${
                activeTab === 'history' 
                  ? 'bg-emerald-950/20 text-emerald-400 border-emerald-800/20 shadow-sm' 
                  : 'text-slate-400 border-transparent hover:bg-slate-900/40 hover:text-white'
              }`}
            >
              <ArrowLeftRight className="h-3.5 w-3.5" />
              Transaction History
            </button>

            {currentUser.role === 'admin' && (
              <button 
                onClick={() => setActiveTab('admin')}
                aria-label="Admin Control"
                className={`flex items-center gap-2 px-3 py-2 rounded text-xs font-bold transition whitespace-nowrap md:w-full border ${
                  activeTab === 'admin' 
                    ? 'bg-rose-950/20 text-rose-450 border-rose-900/30' 
                    : 'text-rose-500/80 border-transparent hover:bg-slate-900/40 hover:text-rose-400'
                }`}
              >
                <Sliders className="h-3.5 w-3.5" />
                Admin Dashboard
              </button>
            )}

            <div className="hidden md:block mt-6 p-3 rounded border border-slate-900 bg-slate-950/10">
              <span className="text-[9px] font-bold tracking-wider uppercase text-slate-500 block mb-1">CPA Technical Link</span>
              <p className="text-[10px] text-slate-400 leading-relaxed font-mono">
                Auto-tracks affiliate leads via custom click_id parameters.
              </p>
            </div>
          </aside>

          {/* Main Display Window */}
          <main className="flex-1 min-w-0 bg-[#090d15] border border-slate-900 rounded-md p-4 shadow-xl relative">
            
            {/* Tab: Dashboard Overview */}
            {activeTab === 'dashboard' && (
              <div>
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 mb-4.5">
                  <div>
                    <h1 className="text-base font-bold tracking-tight text-white font-display">User Reward Dashboard</h1>
                    <p className="text-[10px] text-slate-400">Manage balances, cashout earnings, and access premium CPA partnerships.</p>
                  </div>
                  <button 
                    onClick={() => setRefreshTrigger(prev => prev + 1)}
                    className="py-1 px-2.5 text-slate-400 hover:text-emerald-400 border border-slate-800 rounded hover:bg-slate-900 flex items-center gap-1.5 text-[10px] transition"
                  >
                    <RefreshCw className="h-3.5 w-3.5" />
                    Sync Wallet
                  </button>
                </div>

                {/* Dashboard Metrics Hero */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
                  
                  <div className="bg-[#0b0e15] border border-slate-900 rounded p-3.5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-10 w-10 bg-emerald-500/5 rounded-bl-full flex items-center justify-center">
                      <Coins className="h-4 w-4 text-emerald-500/10" />
                    </div>
                    <span className="text-slate-400 text-[10px] font-semibold block mb-0.5">Available Coins</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xl font-bold font-mono text-white tracking-tight">${currentUser.balance.toFixed(2)}</span>
                      <span className="text-[9px] font-mono text-emerald-400">USDT</span>
                    </div>
                    <span className="text-[9px] text-slate-500 block mt-1">Ready to cash out instantly</span>
                  </div>

                  <div className="bg-[#0b0e15] border border-slate-900 rounded p-3.5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-10 w-10 bg-teal-500/5 rounded-bl-full flex items-center justify-center">
                      <TrendingUp className="h-4 w-4 text-teal-500/10" />
                    </div>
                    <span className="text-slate-400 text-[10px] font-semibold block mb-0.5">Net Commissions</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xl font-bold font-mono text-white tracking-tight">${currentUser.totalEarnings.toFixed(2)}</span>
                      <span className="text-[9px] font-mono text-teal-400 font-semibold">USDT</span>
                    </div>
                    <span className="text-[9px] text-slate-500 block mt-1">Cumulative lifetime rewards payout</span>
                  </div>

                  <div className="bg-[#0b0e15] border border-slate-900 rounded p-3.5 relative overflow-hidden">
                    <div className="absolute top-0 right-0 h-10 w-10 bg-indigo-500/5 rounded-bl-full flex items-center justify-center">
                      <CheckCircle className="h-4 w-4 text-indigo-500/10" />
                    </div>
                    <span className="text-slate-400 text-[10px] font-semibold block mb-0.5">Completed Offers</span>
                    <div className="flex items-baseline gap-1.5">
                      <span className="text-xl font-bold font-mono text-white tracking-tight">{currentUser.completedTasksCount}</span>
                      <span className="text-[9px] font-mono text-indigo-400 font-semibold">TASKS</span>
                    </div>
                    <span className="text-[9px] text-emerald-400 block mt-1 font-medium">Conversion success rate 100%</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  
                  {/* Left component: Offerwall summary */}
                  <div className="bg-slate-950/20 border border-slate-900 rounded p-3.5">
                    <div className="flex justify-between items-center mb-3">
                      <h3 className="text-[10px] font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5">
                        <Award className="h-3.5 w-3.5 text-emerald-400" />
                        Premium Partner Offerwall
                      </h3>
                      <button 
                        onClick={() => setActiveTab('offers')}
                        className="text-[10px] text-emerald-400 hover:underline flex items-center gap-1 font-medium"
                      >
                        Browse All
                        <ArrowRight className="h-3 w-3" />
                      </button>
                    </div>

                    <div className="space-y-2">
                      {offers.slice(0, 3).map(off => (
                        <div key={off.id} className="bg-[#080d16]/70 border border-slate-900 p-2.5 rounded flex items-center justify-between gap-3">
                          <div className="flex items-center gap-2.5">
                            <img 
                              src={off.image_url} 
                              alt={off.title} 
                              referrerPolicy="no-referrer"
                              className="h-8 w-8 rounded object-cover bg-slate-800"
                            />
                            <div>
                              <h4 className="text-[11px] font-bold text-slate-100 truncate max-w-[130px]">{off.title}</h4>
                              <p className="text-[9px] text-slate-400 max-w-[160px] truncate">{off.description}</p>
                            </div>
                          </div>
                          
                          <div className="text-right shrink-0">
                            <span className="text-[11px] font-mono font-bold text-emerald-400 block">+${off.payout.toFixed(2)}</span>
                            <span className="text-[8px] text-slate-500 font-semibold block">{off.category}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Right Component: Recent conversion feeds */}
                  <div className="bg-slate-950/20 border border-slate-900 rounded p-3.5">
                    <h3 className="text-[10px] font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5 mb-3">
                      <Activity className="h-3.5 w-3.5 text-teal-400" />
                      Recent Activity Feed
                    </h3>

                    <div className="space-y-2 max-h-[160px] overflow-y-auto pr-1">
                      {userStats?.recentTransactions && userStats.recentTransactions.length > 0 ? (
                        userStats.recentTransactions.slice(0, 4).map(txn => (
                          <div key={txn.id} className="text-[11px] border-b border-slate-900/40 pb-2 last:border-0 last:pb-0 flex justify-between items-center gap-3">
                            <div>
                              <p className="font-medium text-slate-300">{txn.description}</p>
                              <span className="text-[8px] text-slate-500 font-mono">
                                {new Date(txn.createdAt).toLocaleDateString()} at {new Date(txn.createdAt).toLocaleTimeString()}
                              </span>
                            </div>
                            <span className={`font-mono font-bold text-[11px] shrink-0 ${
                              txn.amount > 0 ? 'text-emerald-400' : 'text-rose-450'
                            }`}>
                              {txn.amount > 0 ? '+' : ''}${txn.amount.toFixed(2)}
                            </span>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-6 text-[10px] text-slate-500">
                          No recent transactions recorded on this account
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Instant Postback Sim Help Card */}
                <div className="mt-4 bg-gradient-to-r from-emerald-950/10 to-teal-950/5 border border-emerald-950/30 rounded p-3.5 flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                  <div>
                    <h4 className="text-[11px] font-bold text-white flex items-center gap-1.5 font-display">
                      <Sparkles className="h-3.5 w-3.5 text-emerald-400" />
                      Developer Postback Sandbox Active
                    </h4>
                    <p className="text-[10px] text-slate-400 leading-relaxed mt-0.5">
                      Test automated CPA callbacks dynamically. Go to the <strong>Offers Offerwall</strong> tab below to fire sample networks postbacks directly and watch your balance count up live.
                    </p>
                  </div>
                  <button 
                    onClick={() => setActiveTab('offers')}
                    className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-[10px] flex items-center gap-1 transition whitespace-nowrap"
                  >
                    Launch Postback Simulator
                    <ArrowRight className="h-3 w-3" />
                  </button>
                </div>
              </div>
            )}

            {/* Tab: Offers Feed/Offerwall */}
            {activeTab === 'offers' && (
              <div>
                <div className="mb-4">
                  <h1 className="text-base font-bold tracking-tight text-white font-display">CPA Rewards Offerwall</h1>
                  <p className="text-[10px] text-slate-400 mt-0.5">Complete partner offers below to credit your USDT balance. Unique tracking parameters are automatically embedded with your account id.</p>
                </div>

                {/* Category navigation tags */}
                <div className="flex flex-wrap items-center gap-1 mb-4 bg-slate-950/25 p-0.5 rounded border border-slate-900 max-w-sm">
                  {['All', 'Survey', 'Gaming', 'Install', 'SignUp'].map((cat) => (
                    <button
                       key={cat}
                       onClick={() => setOffersFilter(cat)}
                       className={`px-2 py-1 rounded text-[9px] font-bold uppercase tracking-wider transition ${
                        offersFilter === cat
                           ? 'bg-emerald-950 text-emerald-450 border border-emerald-900/30'
                           : 'text-slate-400 hover:text-slate-200'
                       }`}
                    >
                      {cat}s
                    </button>
                  ))}
                </div>

                {/* Offers Grid */}
                {isLoading ? (
                  <div className="flex flex-col items-center justify-center py-10 gap-2">
                    <RefreshCw className="h-6 w-6 text-emerald-400 animate-spin" />
                    <span className="text-[10px] text-slate-500">Retrieving dynamic premium CPA inventories...</span>
                  </div>
                ) : filteredOffers.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {filteredOffers.map((off) => {
                      const isSimulatingMe = selectedOfferForSimulation?.id === off.id;
                      return (
                        <div key={off.id} className="bg-[#0b0e15] border border-slate-900 rounded p-3 flex flex-col justify-between hover:border-emerald-500/10 hover:shadow shadow-emerald-950/5 transition">
                          
                          <div className="flex items-start gap-3 mb-3">
                            <img 
                              src={off.image_url} 
                              alt={off.title} 
                              referrerPolicy="no-referrer"
                              className="h-10 w-10 rounded object-cover shrink-0 bg-slate-800 border border-slate-900"
                            />
                            <div className="min-w-0 flex-1">
                              <div className="flex items-center gap-2 mb-0.5">
                                <span className="px-1 py-0.2 text-[7px] uppercase tracking-wide rounded border border-slate-900 bg-slate-950 text-slate-400 font-mono">
                                  {off.category}
                                </span>
                                <span className="text-[9px] text-slate-500 font-mono">ID: {off.id}</span>
                              </div>
                              <h3 className="text-xs font-bold text-white leading-tight truncate">{off.title}</h3>
                              <p className="text-[10px] text-slate-400 leading-normal mt-0.5 truncate" title={off.description}>
                                {off.description}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center justify-between pt-2.5 border-t border-slate-900/80">
                            <div className="flex flex-col">
                              <span className="text-slate-500 text-[8px] uppercase font-bold tracking-tight">Reward commission</span>
                              <span className="text-[11px] font-mono font-bold text-emerald-400">+${off.payout.toFixed(2)} <span className="text-[9px] text-slate-500 font-normal">USDT</span></span>
                            </div>

                            <div className="flex gap-1.5">
                              {/* Simulator hook selector */}
                              <button 
                                onClick={() => {
                                  setSelectedOfferForSimulation(off);
                                  setSimulatedPayout(off.payout.toString());
                                  showToast(`Selected "${off.title}" for Sandbox simulation`, "info");
                                }}
                                className={`px-2 py-1 rounded text-[9px] font-bold tracking-wide transition flex items-center gap-1 ${
                                  isSimulatingMe 
                                    ? 'bg-rose-950/30 border border-rose-900/40 text-rose-350' 
                                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-white hover:bg-[#0f1523]'
                                }`}
                              >
                                <Sliders className="h-2.5 w-2.5 shrink-0" />
                                Select simulator
                              </button>

                              <a 
                                href={off.urlWithTracking} 
                                target="_blank" 
                                rel="noreferrer"
                                referrerPolicy="no-referrer"
                                className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-[10px] flex items-center gap-1 transition"
                              >
                                {off.anchor || "Earn Now"}
                                <ExternalLink className="h-2.5 w-2.5 shrink-0" />
                              </a>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-10 text-slate-500 border border-dashed border-slate-900 rounded">
                    No active offers found parsing category {offersFilter}
                  </div>
                )}

                {/* CPA DEV POSTBACK SIMULATOR CENTER */}
                <div className="mt-5 pt-4 border-t border-slate-900 bg-slate-950/20 rounded p-4 border border-slate-900">
                  <div className="flex items-center gap-1.5 mb-3">
                    <Database className="h-4 w-4 text-rose-400" />
                    <div>
                      <h3 className="text-xs font-bold text-white font-display">CPA Network Postback Simulator</h3>
                      <p className="text-[9px] text-slate-400 font-mono">Evaluate dynamic /api/postback callback parsing and duplicate check guards</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 items-end mb-3">
                    <div>
                      <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">Target Simulated Offer</label>
                      <div className="p-2 bg-[#070a11] border border-slate-900 rounded text-[10px] font-mono text-slate-300 flex justify-between items-center h-8">
                        <span className="truncate mr-2">{selectedOfferForSimulation ? selectedOfferForSimulation.title : 'No offer selected'}</span>
                        <span className="text-[10px] text-emerald-400 font-bold shrink-0">${selectedOfferForSimulation?.payout} USDT</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">Custom Postback Payout ($)</label>
                      <div className="flex gap-1.5">
                        <input 
                          type="number" 
                          step="0.05"
                          value={simulatedPayout}
                          onChange={(e) => setSimulatedPayout(e.target.value)}
                          className="flex-1 px-2.5 py-1.5 bg-[#070a11] border border-slate-850 rounded text-[10px] font-mono text-white focus:outline-none focus:border-rose-500 h-8"
                        />
                        <button 
                          onClick={handleSimulatedPostback}
                          className="px-3 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded text-[10px] transition shrink-0 h-8"
                        >
                          Simulate Callback
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Sandbox raw console logs */}
                  {simulatingLog.status !== 'idle' && (
                    <div className="bg-[#05070c] rounded border border-slate-900 p-3">
                      <div className="flex justify-between items-center mb-1.5 text-[8px] font-mono text-slate-500 uppercase">
                        <span>Simulator Output Stream</span>
                        <span className={`px-1 py-0.2 rounded text-[8px] ${
                          simulatingLog.status === 'success' ? 'bg-[#0a1c14] text-emerald-400' :
                          simulatingLog.status === 'error' ? 'bg-[#1c0a0a55] text-rose-455' :
                          'bg-[#0d1626] text-slate-400 animate-pulse'
                        }`}>
                          {simulatingLog.status}
                        </span>
                      </div>

                      <div className="space-y-1 text-[10px] font-mono">
                        <div className="flex items-start">
                          <span className="text-rose-400 mr-2 shrink-0">HTTP GET Ping:</span>
                          <span className="text-slate-400 break-all">{simulatingLog.url}</span>
                        </div>
                        
                        {simulatingLog.response && (
                          <div className="pt-1.5 border-t border-slate-900">
                            <span className="text-teal-400 mr-2">JSON Response:</span>
                            <pre className="text-[9px] text-slate-300 mt-1 bg-[#030408] p-1.5 rounded overflow-x-auto">
                              {JSON.stringify(simulatingLog.response, null, 2)}
                            </pre>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Tab: Request Withdraw */}
            {activeTab === 'withdraw' && (
              <div>
                <div className="mb-4">
                  <h1 className="text-base font-bold tracking-tight text-white font-display">Capital Withdrawal Portal</h1>
                  <p className="text-[10px] text-slate-400 mt-0.5">Request USDT disbursements over the Tron network (TRC-20) safely and confidently.</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                  
                  {/* Left component: withdraw form */}
                  <form onSubmit={handleWithdrawalRequest} className="lg:col-span-2 space-y-3">
                    <div className="bg-slate-950/20 border border-slate-900 rounded p-4 space-y-3">
                      
                      {withdrawError && (
                        <div className="p-2.5 bg-rose-950/20 border border-rose-900/35 rounded text-[10px] text-rose-300 flex items-start gap-1.5 leading-snug">
                          <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-rose-400" />
                          <span>{withdrawError}</span>
                        </div>
                      )}

                      {withdrawSuccess && (
                        <div className="p-2.5 bg-emerald-950/20 border border-emerald-900/35 rounded text-[10px] text-emerald-350 flex items-start gap-1.5">
                          <CheckCircle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-emerald-400" />
                          <span>{withdrawSuccess}</span>
                        </div>
                      )}

                      <div>
                        <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">USDT TRC-20 Address</label>
                        <input 
                          type="text"
                          required
                          value={usdtAddress}
                          onChange={(e) => setUsdtAddress(e.target.value)}
                          placeholder="e.g. TYG3b1C5as6Tz9Pq7Z1... (starts with T and 34 chars)"
                          className="w-full px-2.5 py-1.5 bg-[#070a11] focus:bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded text-[10px] font-mono text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition"
                        />
                        <span className="text-[8px] text-slate-500 mt-0.5 block font-mono">Tron TRC-20 payouts minimize processing delays</span>
                      </div>

                      <div>
                        <div className="flex justify-between items-center mb-0.5">
                          <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold">Payment Amount (USDT)</label>
                          <button
                            type="button"
                            onClick={() => setWithdrawAmount(currentUser.balance.toFixed(2))}
                            className="text-[9px] text-emerald-400 font-bold hover:underline"
                          >
                            Max: ${currentUser.balance.toFixed(2)}
                          </button>
                        </div>
                        <input 
                          type="number"
                          required
                          min="5.00"
                          step="0.01"
                          value={withdrawAmount}
                          onChange={(e) => setWithdrawAmount(e.target.value)}
                          placeholder="Minimum 5.00 USDT"
                          className="w-full px-2.5 py-1.5 bg-[#070a11] focus:bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded text-[10px] font-mono text-white placeholder-slate-600 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-2 bg-gradient-to-tr from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-bold rounded text-[11px] transition shadow"
                      >
                        Submit Cashout Request
                      </button>
                    </div>

                    <div className="bg-slate-900/10 border border-slate-900 rounded p-3">
                      <h4 className="text-[9px] font-bold text-white mb-1 uppercase tracking-wide flex items-center gap-1">
                        <Info className="h-3 w-3 text-emerald-400" />
                        Disbursement Rules & SLA
                      </h4>
                      <ul className="space-y-1 mt-1 text-[9px] text-slate-450 list-disc pl-3.5 leading-normal">
                        <li>Minimum payout threshold limit: <strong>$5.00 USDT</strong>.</li>
                        <li>Automated safety audits complete processing operations in <strong>2-24 hours</strong>.</li>
                        <li>Rejected withdrawals trigger instant safe balance refunds.</li>
                      </ul>
                    </div>
                  </form>

                  {/* Right component: withdrawal records */}
                  <div className="lg:col-span-3 bg-slate-950/5 border border-slate-900 rounded p-4">
                    <h3 className="text-[10px] font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5 mb-3">
                      <Clock className="h-3.5 w-3.5 text-emerald-400" />
                      Pending & Historic Requests
                    </h3>

                    <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
                      {userStats?.recentWithdrawals && userStats.recentWithdrawals.length > 0 ? (
                        userStats.recentWithdrawals.map(w => (
                          <div key={w.id} className="bg-[#080d16]/80 border border-slate-900/60 p-3 rounded text-[10px] flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-1.5">
                                <span className="font-mono font-bold text-white">${w.amount.toFixed(2)} USDT</span>
                                <span className={`px-1 rounded text-[7px] uppercase tracking-wider font-bold border ${
                                  w.status === 'approved' ? 'bg-emerald-950/20 text-emerald-400 border-emerald-900/20' :
                                  w.status === 'rejected' ? 'bg-rose-950/20 text-rose-350 border-rose-900/20' :
                                  'bg-amber-950/20 text-amber-400 border-amber-900/20'
                                }`}>
                                  {w.status}
                                </span>
                              </div>
                              <p className="text-[9px] text-slate-400 truncate max-w-[180px] sm:max-w-xs font-mono" title={w.usdtAddress}>
                                Wallet: {w.usdtAddress.substring(0, 10)}...{w.usdtAddress.substring(w.usdtAddress.length - 8)}
                              </p>
                              {w.updatedAt && (
                                <span className="text-[8px] text-slate-500 block">
                                  Resolved: {new Date(w.updatedAt).toLocaleDateString()}
                                </span>
                              )}
                            </div>
                            <span className="text-[8px] text-slate-500 font-mono self-end sm:self-auto shrink-0">
                              {new Date(w.createdAt).toLocaleDateString()}
                            </span>
                          </div>
                        ))
                      ) : (
                        <div className="text-center py-12 text-[10px] text-slate-500 border border-dashed border-slate-900 rounded">
                          No previous withdrawal requests logged
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Transaction History */}
            {activeTab === 'history' && (
              <div>
                <div className="mb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h1 className="text-base font-bold tracking-tight text-white font-display">Statement Transactions Log</h1>
                    <p className="text-[10px] text-slate-400 mt-0.5">Complete historic log audits for completed CPA offers, cashed payouts, and refund corrections.</p>
                  </div>
                  <button 
                    onClick={() => setRefreshTrigger(prev => prev + 1)}
                    className="py-1 px-2.5 border border-slate-805 text-slate-400 hover:text-emerald-400 transition hover:bg-slate-900 text-[10px] rounded flex items-center gap-1"
                  >
                    <RefreshCw className="h-3 w-3" />
                    Refresh Lists
                  </button>
                </div>

                <div className="bg-slate-950/20 border border-slate-900 rounded overflow-hidden">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[11px] border-collapse font-mono">
                      <thead>
                        <tr className="bg-slate-950/45 border-b border-slate-900 text-slate-400 uppercase tracking-tight text-[9px] font-bold">
                          <th className="px-3 py-2">Transaction ID</th>
                          <th className="px-3 py-2">Description</th>
                          <th className="px-3 py-2">Category</th>
                          <th className="px-3 py-2">Date & Time</th>
                          <th className="px-3 py-2 text-right">Credit / Debit</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60 font-sans text-slate-300">
                        {userStats?.recentTransactions && userStats.recentTransactions.length > 0 ? (
                          userStats.recentTransactions.map((t) => (
                            <tr key={t.id} className="hover:bg-slate-900/15 transition select-all">
                              <td className="px-3 py-2 font-mono text-[9px] text-slate-500">{t.id}</td>
                              <td className="px-3 py-2 font-medium text-slate-200">{t.description}</td>
                              <td className="px-3 py-2">
                                <span className={`px-1 py-0.2 rounded text-[7px] uppercase font-bold tracking-tight border ${
                                  t.type === 'offer_completion' ? 'bg-emerald-950/20 text-emerald-400 border-emerald-900/20' :
                                  t.type === 'withdrawal' ? 'bg-rose-950/20 text-rose-455 border-rose-900/20' :
                                  t.type === 'signup_bonus' ? 'bg-indigo-950/20 text-indigo-400 border-indigo-900/20' :
                                  'bg-slate-900 text-slate-400'
                                }`}>
                                  {t.type.replace('_', ' ')}
                                </span>
                              </td>
                              <td className="px-3 py-2 text-slate-400 font-mono text-[9px]">
                                {new Date(t.createdAt).toLocaleDateString()} {new Date(t.createdAt).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}
                              </td>
                              <td className={`px-3 py-2 font-mono text-right font-bold text-[11px] ${
                                t.amount > 0 ? 'text-emerald-400' : 'text-rose-455'
                              }`}>
                                {t.amount > 0 ? '+' : ''}${t.amount.toFixed(2)}
                              </td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="text-center py-10 text-[10px] text-slate-500 font-medium">
                              No financial transactions have occurred on this account yet
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}

            {/* Tab: Admin Panel Area (Selective UI) */}
            {activeTab === 'admin' && currentUser.role === 'admin' && (
              <div className="space-y-4 animate-fade-in">
                
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-rose-955/20 pb-3">
                  <div>
                    <h1 className="text-base font-bold tracking-tight text-white font-display flex items-center gap-1.5">
                      <ShieldCheck className="h-4.5 w-4.5 text-rose-500" />
                      Platform Administrative Controls
                    </h1>
                    <p className="text-[10px] text-rose-400/80 mt-0.5">Review live memberships, credit and audit conversion pings, and authorize USDT withdrawal cashouts.</p>
                  </div>
                  <button 
                    onClick={() => setRefreshTrigger(prev => prev + 1)}
                    className="py-1 px-2.5 bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/40 text-rose-350 rounded text-[10px] flex items-center gap-1.5 transition"
                  >
                    <RefreshCw className="h-3 w-3" />
                    Refresh Admin Ledger
                  </button>
                </div>

                {/* KPI Metrics Dashboard Columns */}
                {adminStats && (
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                    <div className="bg-slate-950/20 border border-slate-900 rounded p-3">
                      <span className="text-slate-500 text-[8px] uppercase font-bold tracking-wide block mb-0.5">Total Users</span>
                      <span className="text-lg font-bold text-white font-mono">{adminStats.totalUsers}</span>
                      <span className="text-[8px] text-green-400 block mt-0.5">{adminStats.activeMembers} active member</span>
                    </div>

                    <div className="bg-slate-950/20 border border-slate-900 rounded p-3">
                      <span className="text-slate-500 text-[8px] uppercase font-bold tracking-wide block mb-0.5">Conversions Logged</span>
                      <span className="text-lg font-bold text-white font-mono">{adminStats.totalCPAConversions}</span>
                      <span className="text-[8px] text-green-400 block mt-0.5">+${adminStats.totalCPAEarnings.toFixed(2)} Vol</span>
                    </div>

                    <div className="bg-slate-950/20 border border-slate-900 rounded p-3">
                      <span className="text-slate-500 text-[8px] uppercase font-bold tracking-wide block mb-0.5">Pending Cashouts</span>
                      <span className="text-lg font-bold text-amber-400 font-mono">{adminStats.pendingWithdrawCount}</span>
                      <span className="text-[8px] text-slate-400 block mt-0.5">${adminStats.pendingWithdrawSum.toFixed(2)} USDT value</span>
                    </div>

                    <div className="bg-slate-950/20 border border-slate-900 rounded p-3">
                      <span className="text-slate-500 text-[8px] uppercase font-bold tracking-wide block mb-0.5">Total Paid USDT</span>
                      <span className="text-lg font-bold text-emerald-400 font-mono">${adminStats.totalApprovedPaid.toFixed(2)}</span>
                      <span className="text-[8px] text-emerald-500 block mt-0.5">Disbursed successfully</span>
                    </div>
                  </div>
                )}

                {/* Queue 1: Pending Withdrawals Orders */}
                <div className="bg-slate-950/10 border border-[#2b1b2a] p-4 rounded">
                  <h3 className="text-[10px] font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5 mb-3">
                    <Clock className="h-4 w-4 text-amber-500" />
                    Pending Cashout Queue ({adminWithdrawals.filter(w=>w.status==='pending').length})
                  </h3>

                  <div className="space-y-2">
                    {adminWithdrawals.some(w => w.status === 'pending') ? (
                      adminWithdrawals.filter(w => w.status === 'pending').map((ord) => (
                        <div key={ord.id} className="p-3 bg-[#080c14] border border-slate-900 rounded flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
                          <div className="space-y-0.5">
                            <div className="flex items-center gap-2">
                              <span className="text-[11px] font-mono font-bold text-rose-400">{ord.userEmail}</span>
                              <span className="px-1 py-0.2 rounded text-[7px] uppercase tracking-wider bg-slate-900 border border-slate-800 text-slate-450 font-bold">UID: {ord.userId}</span>
                            </div>
                            
                            <div className="flex items-center gap-2 text-[10px]">
                              <span className="font-bold text-white font-mono">${ord.amount.toFixed(2)} USDT</span>
                              <span className="text-slate-600">|</span>
                              <span className="font-mono text-slate-400 truncate max-w-xs" title={ord.usdtAddress}>TRC20 Wallet: {ord.usdtAddress}</span>
                            </div>
                            <span className="text-[8px] text-slate-500 block">Requested: {new Date(ord.createdAt).toLocaleString()}</span>
                          </div>

                          <div className="flex items-center gap-1.5 shrink-0 self-end md:self-auto">
                            <button 
                              onClick={() => handleRejectWithdrawal(ord.id)}
                              className="px-2 py-1 bg-rose-950/20 border border-rose-900/30 hover:bg-rose-900/30 text-rose-350 font-bold rounded text-[9px] transition flex items-center gap-1"
                            >
                              <X className="h-2.5 w-2.5" />
                              Reject & Refund
                            </button>
                            <button 
                              onClick={() => handleApproveWithdrawal(ord.id)}
                              className="px-2.5 py-1 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold rounded text-[9px] transition flex items-center gap-1"
                            >
                              <Check className="h-2.5 w-2.5" />
                              Approve Pay
                            </button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-[10px] text-slate-500 bg-slate-950/10 border border-dashed border-slate-900 rounded">
                        Clean Slate! No withdrawals are currently sitting in pending confirmation queues.
                      </div>
                    )}
                  </div>
                </div>

                {/* Queue 2: System Members List */}
                <div className="bg-slate-950/10 border border-slate-900 rounded p-4">
                  <h3 className="text-[10px] font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5 mb-3">
                    <Users className="h-4 w-4 text-rose-400" />
                    Rewards Member Database Accounts ({adminUsers.length})
                  </h3>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[11px] border-collapse font-mono">
                      <thead>
                        <tr className="bg-slate-950/45 border-b border-slate-900 text-slate-400 uppercase tracking-tight text-[9px] font-bold">
                          <th className="px-3 py-2">User Email</th>
                          <th className="px-3 py-2">Role</th>
                          <th className="px-3 py-2">Completed Tasks</th>
                          <th className="px-3 py-2 text-right">Available Balance</th>
                          <th className="px-3 py-2 text-right">Cumulative Commissions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60 font-sans text-slate-300">
                        {adminUsers.map((u) => (
                          <tr key={u.id} className="hover:bg-slate-900/10">
                            <td className="px-3 py-2 font-mono font-bold text-slate-200 select-all">{u.email}</td>
                            <td className="px-3 py-2">
                              <span className={`px-1 py-0.2 rounded text-[8px] uppercase font-bold border ${
                                u.role === 'admin' ? 'bg-rose-950/30 text-rose-450 border-rose-900/30' : 'bg-slate-900 text-slate-405 border-slate-800/60'
                              }`}>
                                {u.role}
                              </span>
                            </td>
                            <td className="px-3 py-2 text-slate-300 font-mono text-[10px]">{u.completedTasksCount} completed</td>
                            <td className="px-3 py-2 text-right font-mono font-bold text-emerald-450">${u.balance.toFixed(2)}</td>
                            <td className="px-3 py-2 text-right font-mono text-slate-450">${u.totalEarnings.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Queue 3: Platform Live Postbacks */}
                <div className="bg-slate-950/10 border border-slate-900 rounded p-4">
                  <h3 className="text-[10px] font-bold text-white uppercase tracking-wider font-display flex items-center gap-1.5 mb-3">
                    <Activity className="h-4 w-4 text-rose-400" />
                    Incoming Affiliate Partner Callbacks (Postbacks Feed) ({adminConversions.length})
                  </h3>

                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-[11px] border-collapse font-mono">
                      <thead>
                        <tr className="bg-slate-950/45 border-b border-slate-900 text-slate-400 uppercase tracking-tight text-[9px] font-bold">
                          <th className="px-3 py-2">ID / TxHash</th>
                          <th className="px-3 py-2">Recipient Email</th>
                          <th className="px-3 py-2">CPA Offer Name</th>
                          <th className="px-3 py-2">Time Occurred</th>
                          <th className="px-3 py-2 text-right">Commission Credit</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-900/60 font-sans text-slate-300">
                        {adminConversions.length > 0 ? (
                          adminConversions.map((cn) => (
                            <tr key={cn.id} className="hover:bg-slate-900/10">
                              <td className="px-3 py-2 font-mono text-[9px] text-slate-500 select-all">{cn.id}</td>
                              <td className="px-3 py-2 font-mono text-slate-300 select-all">{cn.userEmail}</td>
                              <td className="px-3 py-2 font-medium text-slate-200">{cn.offerName}</td>
                              <td className="px-3 py-2 text-slate-500 font-mono text-[9px]">{new Date(cn.createdAt).toLocaleString()}</td>
                              <td className="px-3 py-2 text-right font-mono font-bold text-emerald-450">+${cn.payout.toFixed(2)}</td>
                            </tr>
                          ))
                        ) : (
                          <tr>
                            <td colSpan={5} className="text-center py-10 text-[10px] text-slate-500 font-medium">No external conversions occurred yet on the network.</td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>

              </div>
            )}

          </main>
        </div>
      ) : (
        /* Guest Authorization Splash Container */
        <div className="flex-1 max-w-sm w-full mx-auto px-4 flex flex-col justify-center py-6">
          <div className="bg-[#090d15] border border-slate-900 p-5 rounded-md shadow-2xl relative">
            
            <div className="flex flex-col items-center text-center mb-5">
              <div className="h-10 w-10 rounded bg-gradient-to-tr from-emerald-600 to-teal-500 flex items-center justify-center shadow mb-3">
                <Coins className="h-5 w-5 text-[#0b0f19] stroke-[2.5]" />
              </div>
              <h2 className="text-base font-bold text-white tracking-tight font-display">Reward<span className="text-emerald-400">Task</span> Partnerships</h2>
              <p className="text-[10px] text-slate-400 mt-1 leading-normal">
                Connect simple daily activities, surveys, and app evaluations into real cashed balances. Join thousands of users globally.
              </p>
            </div>

            <div className="flex bg-[#05070a]/80 p-0.5 rounded border border-slate-900 mb-4">
              <button 
                type="button"
                onClick={() => { setAuthMode('login'); setAuthError(''); }}
                className={`flex-1 py-1.5 text-[10px] font-bold rounded transition ${
                  authMode === 'login' ? 'bg-slate-905 border border-slate-900 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                Access Account
              </button>
              <button 
                type="button"
                onClick={() => { setAuthMode('signup'); setAuthError(''); }}
                className={`flex-1 py-1.5 text-[10px] font-bold rounded transition ${
                  authMode === 'signup' ? 'bg-slate-905 border border-slate-900 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                New Registration
              </button>
            </div>

            {authError && (
              <div className="mb-3 p-2.5 bg-rose-950/20 border border-rose-900/30 rounded text-[10px] text-rose-300 flex items-start gap-1.5 leading-snug">
                <AlertCircle className="h-3.5 w-3.5 shrink-0 mt-0.5 text-rose-400" />
                <span>{authError}</span>
              </div>
            )}

            {authMode === 'login' ? (
              <form onSubmit={handleLogin} className="space-y-3">
                <div>
                  <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">Email Account Address</label>
                  <input 
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full px-2.5 py-1.5 bg-[#070a11] focus:bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded text-[10px] text-white placeholder-slate-650 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition"
                  />
                </div>

                <div>
                  <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">Access Password</label>
                  <input 
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••••••"
                    className="w-full px-2.5 py-1.5 bg-[#070a11] focus:bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded text-[10px] text-white placeholder-slate-650 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2 bg-gradient-to-tr from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-bold rounded text-[10px] tracking-wider transition shadow"
                >
                  {isLoading ? 'Decrypting credentials...' : 'Authenticate Profile'}
                </button>
              </form>
            ) : (
              <form onSubmit={handleSignup} className="space-y-3">
                <div>
                  <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">Email Address</label>
                  <input 
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="you@example.com"
                    className="w-full px-2.5 py-1.5 bg-[#070a11] focus:bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded text-[10px] text-white placeholder-slate-650 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition"
                  />
                </div>

                <div>
                  <label className="text-[9px] uppercase tracking-wider text-slate-400 font-bold block mb-0.5">Choose Password</label>
                  <input 
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Minimum 6 characters"
                    className="w-full px-2.5 py-1.5 bg-[#070a11] focus:bg-slate-950 border border-slate-800 focus:border-emerald-500 rounded text-[10px] text-white placeholder-slate-650 focus:outline-none focus:ring-1 focus:ring-emerald-500 transition"
                  />
                </div>

                <div className="p-2 bg-emerald-950/20 border border-emerald-900/30 rounded text-[9px] text-emerald-400 leading-normal font-bold">
                  🎁 BONUS: New registrations claim an instant $5.00 USDT activation credit automatically!
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full py-2 bg-gradient-to-tr from-emerald-600 to-teal-500 hover:from-emerald-500 hover:to-teal-400 text-slate-950 font-bold rounded text-[10px] tracking-wider transition shadow"
                >
                  {isLoading ? 'Creating secure vault...' : 'Complete Registration'}
                </button>
              </form>
            )}

            {/* Divider */}
            <div className="relative my-4 select-none">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-slate-900/60"></div>
              </div>
              <div className="relative flex justify-center text-[7px] uppercase tracking-wider font-mono">
                <span className="bg-[#090d15] px-2 text-slate-500 font-bold">Secure Integrations Port</span>
              </div>
            </div>

            {/* Google Sign In Button */}
            <button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              className="w-full py-1.5 px-3 border border-slate-800 hover:border-emerald-500/40 bg-[#05070a]/60 hover:bg-[#070a12]/80 text-[10px] text-slate-200 font-bold rounded flex items-center justify-center gap-2 transition shadow-sm cursor-pointer"
            >
              {/* Google SVG Icon */}
              <svg viewBox="0 0 24 24" className="h-4.5 w-4.5 shrink-0 select-none">
                <path fill="#EA4335" d="M12.24 10.285V14.4h6.887c-.648 2.41-2.519 4.114-5.136 4.114-3.466 0-6.277-2.85-6.277-6.36s2.811-6.358 6.277-6.358c1.5 0 2.87.53 3.939 1.48L20.9 4.113C18.665 1.956 15.65.6 12.24.6 6.012.6 1 5.688 1 12s5.012 11.4 11.24 11.4c6.26 0 11.24-5.013 11.24-11.4 0-.741-.091-1.346-.242-1.715H12.24z"/>
              </svg>
              <span>Instant Google Sign In / Up</span>
            </button>

            {/* QUICK SANDBOX CONTROLS */}
            <div className="mt-5 pt-4 border-t border-slate-900/60">
              <span className="text-[8px] uppercase font-bold tracking-wider text-slate-500 block mb-2 text-center">Interactive Evaluation Sandboxes</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => triggerQuickLogin('user')}
                  className="px-2 py-1.5 bg-slate-900/40 border border-slate-800 hover:border-emerald-800 hover:bg-slate-950 transition text-slate-300 font-bold text-[10px] rounded flex items-center justify-center gap-1"
                >
                  <User className="h-3 w-3 text-emerald-400 shrink-0" />
                  Quick User Me
                </button>
                <button
                  type="button"
                  onClick={() => triggerQuickLogin('admin')}
                  className="px-2 py-1.5 bg-slate-900/40 border border-slate-800 hover:border-rose-900 hover:bg-slate-950 transition text-rose-450 font-bold text-[10px] rounded flex items-center justify-center gap-1"
                >
                  <ShieldCheck className="h-3 w-3 text-rose-500 shrink-0" />
                  Quick Admin Me
                </button>
              </div>
            </div>

          </div>
        </div>
      )}

      {/* Footer Margins */}
      <footer className="mt-auto border-t border-slate-900 bg-[#04060b] py-4 text-center text-[10px] text-slate-500 select-none">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row justify-between items-center gap-3">
          <p>© 2026 RewardTask Corporation. Premium micro-credits CPA reward system.</p>
          <div className="flex gap-3">
            <span className="text-[10px] text-slate-500">TRC-20: <span className="text-emerald-400 font-mono">● Active</span></span>
            <span className="text-slate-800">|</span>
            <span className="text-[10px] text-slate-500">Postback Callback: <span className="text-teal-400 font-mono">● Active</span></span>
          </div>
        </div>
      </footer>
    </div>
  );
}
