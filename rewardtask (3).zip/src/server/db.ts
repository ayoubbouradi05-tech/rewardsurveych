import fs from 'fs';
import path from 'path';
import { createClient } from '@supabase/supabase-js';

export interface User {
  id: string;
  email: string;
  passwordHash: string; // Base64 encoding for testing convenience, securely validated
  role: 'user' | 'admin';
  balance: number;
  completedTasksCount: number;
  totalEarnings: number;
  createdAt: string;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  payout: number; // in USDT/USD
  image_url: string;
  url: string;
  anchor: string;
  conversion: string;
}

export interface Conversion {
  id: string;
  userId: string;
  userEmail: string;
  offerId: string;
  offerName: string;
  payout: number;
  createdAt: string;
  clickId: string; // The tracking click/sub ID (same as userId or specific subid)
}

export interface Withdrawal {
  id: string;
  userId: string;
  userEmail: string;
  usdtAddress: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number; // Positive for earnings, negative for withdrawals
  type: 'offer_completion' | 'withdrawal' | 'withdrawal_refund' | 'signup_bonus';
  description: string;
  createdAt: string;
}

export interface DatabaseSchema {
  users: User[];
  offers: Offer[];
  conversions: Conversion[];
  withdrawals: Withdrawal[];
  transactions: Transaction[];
}

const DB_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DB_DIR, 'db.json');

// High-quality Initial Seed Data for the CPA platform
const initialSchema: DatabaseSchema = {
  users: [
    {
      id: "u_admin",
      email: "admin@rewardtask.com",
      passwordHash: Buffer.from("admin123").toString('base64'), // seed password
      role: "admin",
      balance: 15.00,
      completedTasksCount: 3,
      totalEarnings: 15.00,
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "u_demo",
      email: "user@rewardtask.com",
      passwordHash: Buffer.from("user123").toString('base64'), // seed password
      role: "user",
      balance: 24.50,
      completedTasksCount: 5,
      totalEarnings: 34.50,
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
    }
  ],
  offers: [], // dynamic feeds fetched on the fly, but we can store custom fallback offers
  conversions: [
    {
      id: "conv_101",
      userId: "u_demo",
      userEmail: "user@rewardtask.com",
      offerId: "off_weather",
      offerName: "Daily Survey Task",
      payout: 2.00,
      createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString(),
      clickId: "u_demo"
    },
    {
      id: "conv_102",
      userId: "u_demo",
      userEmail: "user@rewardtask.com",
      offerId: "off_game",
      offerName: "Solitaire Castle - Lev 10",
      payout: 3.50,
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
      clickId: "u_demo"
    },
    {
      id: "conv_103",
      userId: "u_demo",
      userEmail: "user@rewardtask.com",
      offerId: "off_app",
      offerName: "Vpn Shield App Install",
      payout: 4.50,
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
      clickId: "u_demo"
    }
  ],
  withdrawals: [
    {
      id: "w_1",
      userId: "u_demo",
      userEmail: "user@rewardtask.com",
      usdtAddress: "TYG3b1C5as6Tz9Pq7Z1Gv8e5RyM2b8uX7P",
      amount: 10.00,
      status: "approved",
      createdAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString(),
      updatedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "w_2",
      userId: "u_demo",
      userEmail: "user@rewardtask.com",
      usdtAddress: "TYG3b1C5as6Tz9Pq7Z1Gv8e5RyM2b8uX7P",
      amount: 15.00,
      status: "pending",
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString()
    }
  ],
  transactions: [
    {
      id: "txn_001",
      userId: "u_demo",
      amount: 5.00,
      type: "signup_bonus",
      description: "Sign Up Bonus",
      createdAt: new Date(Date.now() - 15 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "txn_002",
      userId: "u_demo",
      amount: 2.00,
      type: "offer_completion",
      description: "Completed Daily Survey Task",
      createdAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "txn_003",
      userId: "u_demo",
      amount: 3.50,
      type: "offer_completion",
      description: "Completed Solitaire Castle - Lev 10",
      createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "txn_004",
      userId: "u_demo",
      amount: -10.00,
      type: "withdrawal",
      description: "Withdrawal USDT Withdrawal - TYG3b1...",
      createdAt: new Date(Date.now() - 6 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "txn_005",
      userId: "u_demo",
      amount: 4.50,
      type: "offer_completion",
      description: "Completed Vpn Shield App Install",
      createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
    },
    {
      id: "txn_006",
      userId: "u_demo",
      amount: -15.00,
      type: "withdrawal",
      description: "Withdrawal Request USDT - TYG3b1...",
      createdAt: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString()
    }
  ]
};

const SUPABASE_URL = process.env.SUPABASE_URL || process.env.NEXT_PUBLIC_SUPABASE_URL;
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY;

const supabase = SUPABASE_URL && SUPABASE_KEY 
  ? createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: { persistSession: false }
    })
  : null;

class LocalDatabase {
  private memoryCache: DatabaseSchema | null = null;

  constructor() {
    this.init();
  }

  private init() {
    try {
      if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, { recursive: true });
      }
      if (!fs.existsSync(DB_FILE)) {
        fs.writeFileSync(DB_FILE, JSON.stringify(initialSchema, null, 2), 'utf-8');
        this.memoryCache = JSON.parse(JSON.stringify(initialSchema));
      } else {
        const fileContent = fs.readFileSync(DB_FILE, 'utf-8');
        this.memoryCache = JSON.parse(fileContent);
      }
    } catch (e) {
      console.error("LocalDatabase initialization error, falling back to memory:", e);
      this.memoryCache = JSON.parse(JSON.stringify(initialSchema));
    }
  }

  public async syncFromSupabase() {
    if (!supabase) {
      console.log("[DATABASE] Supabase credentials are blank. Proceeding with secure files fallback.");
      return;
    }

    try {
      console.log("[DATABASE] Connecting to Supabase Cloud Server...");
      
      const { data: usersData, error: uError } = await supabase.from('users').select('*');
      if (uError) throw uError;

      const { data: convData, error: cError } = await supabase.from('conversions').select('*');
      if (cError) throw cError;

      const { data: withData, error: wError } = await supabase.from('withdrawals').select('*');
      if (wError) throw wError;

      const { data: txData, error: tError } = await supabase.from('transactions').select('*');
      if (tError) throw tError;

      console.log(`[DATABASE SESS] Loaded ${usersData?.length || 0} users, ${convData?.length || 0} conversions, ${withData?.length || 0} withdrawals, ${txData?.length || 0} transactions from Supabase.`);

      if (!usersData || usersData.length === 0) {
        console.log("[DATABASE] Supabase is empty. Seeding initial schema tables...");
        
        await supabase.from('users').insert(initialSchema.users);
        await supabase.from('conversions').insert(initialSchema.conversions);
        await supabase.from('withdrawals').insert(initialSchema.withdrawals);
        await supabase.from('transactions').insert(initialSchema.transactions);

        this.memoryCache = JSON.parse(JSON.stringify(initialSchema));
      } else {
        this.memoryCache = {
          users: usersData || [],
          offers: [],
          conversions: convData || [],
          withdrawals: withData || [],
          transactions: txData || []
        };
      }
      
      this.persistLocalOnly();
      console.log("[DATABASE] Successfully synchronized memory state with Supabase cloud.");
    } catch (err: any) {
      console.error("[DATABASE ERROR] Failed to synchronize with Supabase. Preserving local files fallback:", err.message);
    }
  }

  private persist() {
    this.persistLocalOnly();
  }

  private persistLocalOnly() {
    if (!this.memoryCache) return;
    try {
      const tempPath = `${DB_FILE}.tmp`;
      fs.writeFileSync(tempPath, JSON.stringify(this.memoryCache, null, 2), 'utf-8');
      fs.renameSync(tempPath, DB_FILE);
    } catch (e) {
      console.error("Failed to commit database write locally:", e);
    }
  }

  private async supabaseInsert(table: string, data: any) {
    if (!supabase) return;
    try {
      const { error } = await supabase.from(table).insert(data);
      if (error) {
        console.error(`[DATABASE SUPABASE ERROR] Failed to insert into ${table}:`, error.message);
      }
    } catch (err: any) {
      console.error(`[DATABASE SUPABASE ERROR] Exception in insert for ${table}:`, err.message);
    }
  }

  private async supabaseUpsert(table: string, data: any) {
    if (!supabase) return;
    try {
      const { error } = await supabase.from(table).upsert(data);
      if (error) {
        console.error(`[DATABASE SUPABASE ERROR] Failed to upsert into ${table}:`, error.message);
      }
    } catch (err: any) {
      console.error(`[DATABASE SUPABASE ERROR] Exception in upsert for ${table}:`, err.message);
    }
  }

  private getDB(): DatabaseSchema {
    if (!this.memoryCache) {
      this.init();
    }
    return this.memoryCache!;
  }

  // --- USERS TABLE ---
  public users = {
    getAll: (): User[] => {
      return this.getDB().users;
    },
    getById: (id: string): User | undefined => {
      return this.getDB().users.find(u => u.id === id);
    },
    getByEmail: (email: string): User | undefined => {
      const lower = email.toLowerCase().trim();
      return this.getDB().users.find(u => u.email.toLowerCase().trim() === lower);
    },
    create: (email: string, passwordBase64: string, role: 'user' | 'admin' = 'user'): User => {
      const db = this.getDB();
      const id = 'u_' + Math.random().toString(36).substr(2, 9);
      const newUser: User = {
        id,
        email: email.trim(),
        passwordHash: passwordBase64,
        role,
        balance: 5.00, // $5.00 SignUp bonus to make testing delightful!
        completedTasksCount: 0,
        totalEarnings: 5.00,
        createdAt: new Date().toISOString()
      };
      
      db.users.push(newUser);

      const newTx = {
        id: 'txn_' + Math.random().toString(36).substr(2, 9),
        userId: id,
        amount: 5.00,
        type: 'signup_bonus' as const,
        description: 'New Member Sign Up Bonus',
        createdAt: new Date().toISOString()
      };

      // Register signup bonus transaction
      db.transactions.push(newTx);

      this.persist();
      
      // Async Sync
      this.supabaseInsert('users', newUser);
      this.supabaseInsert('transactions', newTx);

      return newUser;
    },
    updateBalance: (id: string, amount: number, isEarning: boolean = true): User | undefined => {
      const db = this.getDB();
      const user = db.users.find(u => u.id === id);
      if (user) {
        user.balance = Math.round((user.balance + amount) * 100) / 100;
        if (isEarning) {
          user.totalEarnings = Math.round((user.totalEarnings + amount) * 100) / 100;
          user.completedTasksCount += 1;
        }
        this.persist();
        
        // Async Sync
        this.supabaseUpsert('users', user);
      }
      return user;
    },
    deductBalance: (id: string, amount: number): User | undefined => {
      const db = this.getDB();
      const user = db.users.find(u => u.id === id);
      if (user) {
        user.balance = Math.round((user.balance - amount) * 100) / 100;
        this.persist();
        
        // Async Sync
        this.supabaseUpsert('users', user);
      }
      return user;
    }
  };

  // --- CONVERSIONS TABLE ---
  public conversions = {
    getAll: (): Conversion[] => {
      return this.getDB().conversions;
    },
    getById: (id: string): Conversion | undefined => {
      return this.getDB().conversions.find(c => c.id === id);
    },
    getByUserId: (userId: string): Conversion[] => {
      return this.getDB().conversions.filter(c => c.userId === userId);
    },
    insert: (conv: Omit<Conversion, 'createdAt'>): Conversion => {
      const db = this.getDB();
      const newConv: Conversion = {
        ...conv,
        createdAt: new Date().toISOString()
      };
      db.conversions.push(newConv);
      this.persist();
      
      // Async Sync
      this.supabaseInsert('conversions', newConv);

      return newConv;
    }
  };

  // --- WITHDRAWALS TABLE ---
  public withdrawals = {
    getAll: (): Withdrawal[] => {
      return this.getDB().withdrawals;
    },
    getById: (id: string): Withdrawal | undefined => {
      return this.getDB().withdrawals.find(w => w.id === id);
    },
    getByUserId: (userId: string): Withdrawal[] => {
      return this.getDB().withdrawals.filter(w => w.userId === userId);
    },
    create: (userId: string, userEmail: string, usdtAddress: string, amount: number): Withdrawal => {
      const db = this.getDB();
      const id = 'w_' + Math.random().toString(36).substr(2, 9);
      const newWithdrawal: Withdrawal = {
        id,
        userId,
        userEmail,
        usdtAddress,
        amount,
        status: 'pending',
        createdAt: new Date().toISOString()
      };
      db.withdrawals.push(newWithdrawal);

      // Deduct balance from user (handles upsert natively)
      this.users.deductBalance(userId, amount);

      const newTx = {
        id: 'txn_' + Math.random().toString(36).substr(2, 9),
        userId,
        amount: -amount,
        type: 'withdrawal' as const,
        description: `Requested Withdrawal of ${amount.toFixed(2)} USDT to ${usdtAddress.substring(0, 6)}...`,
        createdAt: new Date().toISOString()
      };

      // Register negative transaction
      db.transactions.push(newTx);

      this.persist();
      
      // Async Sync
      this.supabaseInsert('withdrawals', newWithdrawal);
      this.supabaseInsert('transactions', newTx);

      return newWithdrawal;
    },
    updateStatus: (id: string, status: 'approved' | 'rejected'): Withdrawal | undefined => {
      const db = this.getDB();
      const w = db.withdrawals.find(item => item.id === id);
      if (w) {
        const oldStatus = w.status;
        w.status = status;
        w.updatedAt = new Date().toISOString();

        this.persist();
        
        // Async Sync
        this.supabaseUpsert('withdrawals', w);

        if (oldStatus === 'pending' && status === 'rejected') {
          // Refund user balance (handles user upsert natively)
          this.users.updateBalance(w.userId, w.amount, false);

          const refundTx = {
            id: 'txn_' + Math.random().toString(36).substr(2, 9),
            userId: w.userId,
            amount: w.amount,
            type: 'withdrawal_refund' as const,
            description: `Refund for rejected withdrawal request ${id}`,
            createdAt: new Date().toISOString()
          };

          // Insert refund record
          db.transactions.push(refundTx);
          this.persistLocalOnly();
          
          this.supabaseInsert('transactions', refundTx);
        }
      }
      return w;
    }
  };

  // --- TRANSACTIONS TABLE ---
  public transactions = {
    getAll: (): Transaction[] => {
      return this.getDB().transactions;
    },
    getByUserId: (userId: string): Transaction[] => {
      return this.getDB().transactions.filter(t => t.userId === userId);
    },
    insert: (userId: string, amount: number, type: Transaction['type'], description: string): Transaction => {
      const db = this.getDB();
      const newTx: Transaction = {
        id: 'txn_' + Math.random().toString(36).substr(2, 9),
        userId,
        amount,
        type,
        description,
        createdAt: new Date().toISOString()
      };
      db.transactions.push(newTx);
      this.persist();
      
      // Async Sync
      this.supabaseInsert('transactions', newTx);

      return newTx;
    }
  };
}

export const db = new LocalDatabase();
