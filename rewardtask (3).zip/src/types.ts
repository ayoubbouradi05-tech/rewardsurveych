export interface User {
  id: string;
  email: string;
  role: 'user' | 'admin';
  balance: number;
  completedTasksCount: number;
  totalEarnings: number;
}

export interface Offer {
  id: string;
  title: string;
  description: string;
  payout: number;
  image_url: string;
  category: 'Survey' | 'Gaming' | 'Install' | 'SignUp' | string;
  url: string;
  anchor: string;
  urlWithTracking: string;
}

export interface Conversion {
  id: string;
  userId: string;
  userEmail: string;
  offerId: string;
  offerName: string;
  payout: number;
  createdAt: string;
  clickId: string;
}

export interface Withdrawal {
  id: string;
  userId: string;
  userEmail: string;
  usdtAddress: string;
  amount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  updatedAt?: string;
}

export interface Transaction {
  id: string;
  userId: string;
  amount: number;
  type: 'offer_completion' | 'withdrawal' | 'withdrawal_refund' | 'signup_bonus';
  description: string;
  createdAt: string;
}

export interface DashboardStats {
  balance: number;
  completedTasksCount: number;
  totalEarnings: number;
  recentConversions: Conversion[];
  recentTransactions: Transaction[];
  recentWithdrawals: Withdrawal[];
}

export interface AdminStats {
  totalUsers: number;
  activeMembers: number;
  totalCPAConversions: number;
  totalCPAEarnings: number;
  pendingWithdrawCount: number;
  pendingWithdrawSum: number;
  totalApprovedPaid: number;
}
