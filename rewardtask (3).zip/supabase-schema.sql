-- ==========================================
-- REWARDTASK SUPABASE DATABASE SCHEMAS
-- Copy and paste this script in your Supabase SQL Editor of your new project!
-- ==========================================

-- 1. Create Users Table
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  "passwordHash" TEXT NOT NULL,
  role TEXT DEFAULT 'user',
  balance DOUBLE PRECISION DEFAULT 5.00,
  "completedTasksCount" INTEGER DEFAULT 0,
  "totalEarnings" DOUBLE PRECISION DEFAULT 5.00,
  "createdAt" TIMESTAMPTZ DEFAULT now()
);

-- 2. Create Conversions Table
CREATE TABLE IF NOT EXISTS conversions (
  id TEXT PRIMARY KEY,
  "userId" TEXT REFERENCES users(id) ON DELETE CASCADE,
  "userEmail" TEXT NOT NULL,
  "offerId" TEXT NOT NULL,
  "offerName" TEXT NOT NULL,
  payout DOUBLE PRECISION NOT NULL,
  "createdAt" TIMESTAMPTZ DEFAULT now(),
  "clickId" TEXT
);

-- 3. Create Withdrawals Table
CREATE TABLE IF NOT EXISTS withdrawals (
  id TEXT PRIMARY KEY,
  "userId" TEXT REFERENCES users(id) ON DELETE CASCADE,
  "userEmail" TEXT NOT NULL,
  "usdtAddress" TEXT NOT NULL,
  amount DOUBLE PRECISION NOT NULL,
  status TEXT DEFAULT 'pending',
  "createdAt" TIMESTAMPTZ DEFAULT now(),
  "updatedAt" TIMESTAMPTZ
);

-- 4. Create Transactions Table
CREATE TABLE IF NOT EXISTS transactions (
  id TEXT PRIMARY KEY,
  "userId" TEXT REFERENCES users(id) ON DELETE CASCADE,
  amount DOUBLE PRECISION NOT NULL,
  type TEXT NOT NULL,
  description TEXT NOT NULL,
  "createdAt" TIMESTAMPTZ DEFAULT now()
);

-- ==========================================
-- INDEXES FOR MAXIMUM QUERY PERFORMANCE
-- ==========================================
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_conversions_userId ON conversions("userId");
CREATE INDEX IF NOT EXISTS idx_withdrawals_userId ON withdrawals("userId");
CREATE INDEX IF NOT EXISTS idx_transactions_userId ON transactions("userId");
